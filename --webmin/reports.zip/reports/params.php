<?php
$alpha = range('A','Z');
?>