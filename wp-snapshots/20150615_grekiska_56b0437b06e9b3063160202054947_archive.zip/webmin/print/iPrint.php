<script type="text/javascript">
	 function printTrigger(elementId) {
		var getMyFrame = document.getElementById(elementId);
		getMyFrame.focus();
		getMyFrame.contentWindow.print();
	}
</script>
<!---<iframe id="iFramePdf" src="http://limone.icington.com/webmin/html2pdf/generate/print.php?id=358"></iframe>-->
<iframe id="iFramePdf" src="test.pdf"></iframe>
<input type="button" value="Print" onclick="printTrigger('iFramePdf');" />