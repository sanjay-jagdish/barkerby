<?php
$parameters = $_POST['parameters'];
?>
<h3>Quick Book</h3>

<?php
echo $parameters;
?>