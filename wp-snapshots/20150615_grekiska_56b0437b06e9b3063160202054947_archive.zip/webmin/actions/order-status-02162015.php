<?php session_start();
	include '../config/config.php';
	require_once( 'PHPMailer/PHPMailerAutoload.php' );
	
	function getNameofSignee($id){
		$q=mysql_query("select concat(fname,' ',lname) as name from account where id=(select signatory from reservation_status_history where reservation_id='".$id."' order by id desc limit 1)") or die(mysql_error());
		$r=mysql_fetch_assoc($q);
		
		if(mysql_num_rows($q) > 0){
			return $r['name'];
		}
		else{
			return '';
		}	
	}
	
	function paymentMode($id){
		$q=mysql_query("select payment_mode from reservation where id='".$id."'");
		$r=mysql_fetch_assoc($q);
		
		if($r['payment_mode']=='cash'){
			return 'Kort/Kontant';
		}
		else{
			return 'Faktura';
		}
	}
	
	
	$id=strip_tags($_POST['id']);
	$signatory=strip_tags($_POST['signed']);
	$status=mysql_real_escape_string(strip_tags($_POST['status']));
	
	$default=0;
	$thereason=mysql_real_escape_string(strip_tags($_POST['reason']));
	
	if(isset($thereason)){
		mysql_query("update reservation set approve=".$status.", reason='".$thereason."', approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id) or die(mysql_error());
	}
	else{
		$default=1;
	}
	
	$default2=0;
	$customtime=mysql_real_escape_string(strip_tags($_POST['customtime']));
	
	if(isset($customtime)){
		
		$ctime=explode(" ",$customtime);
		
		mysql_query("update reservation set approve=".$status.", lead_time='".$ctime[0]."', approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id) or die(mysql_error());
	}
	else{
		$default2=1;
	}
	
	if($default==1 & $default2==1){
		mysql_query("update reservation set approve=".$status.", reason='', lead_time=0, approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id) or die(mysql_error());
	}
	mysql_query("INSERT INTO reservation_status_history(date_time,reservation_id,status,account_id,signatory) 
								values(NOW(), ".$id.",".$status.",".$_SESSION['login']['id'].",".$signatory.")");
	mysql_query("insert into log(account_id,description,date_time,ip_address) values(".$_SESSION['login']['id'].",'Set order-status of an order as ".orderStatus($status).".',now(),'".get_client_ip()."')");
	
	//get status minutes
	
	$qy=mysql_query("select minutes from status where id='".$status."'");
	$ry=mysql_fetch_assoc($qy);
	
	$minutes = $ry['minutes'];
	
	if($minutes==0){
		
		$qqy=mysql_query("select lead_time from reservation where id='".$id."'");
		$rry=mysql_fetch_assoc($qqy);
		
		$minutes = $rry['lead_time'];
		
	}
	
	
	if($status==14){
		
		$q=mysql_query("select fname,lname, email from account where id=(select account_id from reservation where id='".$id."')");
		$r=mysql_fetch_assoc($q);
		
		$to = $r['email'];
			
		$name=$r['fname'].' '.$r['lname'];
		
		$subject = 'Status - Take away';
		
		// message
		$message = "
			<html>
				<body>
					<div style='font-size:13px;'>
						Hej ".trim($r['fname'])."! <br><br>
	
						Din beställning har avbokats. Hör av dig till oss om du har några frågor. <br>
						Din order togs emot av: ".getNameofSignee($id)."<br><br>
						 
						John Chris Coffee<br />
						Drottninggatan 29 <br>
						08-10 70 67 <br>
					</div>
				</body>
			</html>
		";
		
		$qc=mysql_query("select id, DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'),'%Y-%m-%d') as thedate, DATE_FORMAT(time,'%H:%i:%s') as time, account_id as accountid from reservation where id='".$id."'") or die(mysql_error());
		
		$rc=mysql_fetch_assoc($qc);
		$thedate = $rc['thedate'];
		$thetime = $rc['time'];
		
		//updating the asap time
		$asap_datetime = $thedate.' '.$thetime;
		mysql_query("update reservation set asap_datetime='".$asap_datetime."' where id='".$id."'") or die(mysql_error());
		
	}
	
	else{
	//for mail
	
	//SELECT ADDTIME(time, SEC_TO_TIME($minutes*60)), time FROM `reservation` order by id asc
		//check if the order is asap
		
		$qry=mysql_query("select asap from reservation where deleted=0 and id='".$id."'") or die(mysql_error());
		$rqy=mysql_fetch_assoc($qry);
		if($rqy['asap']==1){
			//if asap orders
			
			//the format 2014-11-18 03:15:26
			$getnow = date('Y-m-d H:i:s');
			
			$qq=mysql_query("select id, DATE_FORMAT(curdate(),'%Y-%m-%d') as thedate, DATE_FORMAT(ADDTIME('".$getnow."', SEC_TO_TIME(".$minutes."*60)),'%H:%i:%s') as time, account_id as accountid from reservation where id='".$id."'") or die(mysql_error()); 
			
			//$qq=mysql_query("select id, DATE_FORMAT(curdate(),'%b %d, %Y') as thedate, DATE_FORMAT(ADDTIME(now(), SEC_TO_TIME(".$minutes."*60)),'%H:%i') as time, account_id as accountid from reservation where id='".$id."'"); 
			
		}
		else{
			
			$qq=mysql_query("select id, DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'),'%Y-%m-%d') as thedate, DATE_FORMAT(time,'%H:%i:%s') as time, account_id as accountid from reservation where id='".$id."'") or die(mysql_error());
			
			//$qq=mysql_query("select id, DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'),'%b %d, %Y') as thedate, DATE_FORMAT(time,'%k:%i') as time, account_id as accountid from reservation where id='".$id."'"); 
			
		}
		
		
		$rr=mysql_fetch_assoc($qq);
		$thedate = $rr['thedate'];
		$thetime = $rr['time'];
		
		
		
		//added for mailing
		
		$formsg='';
		$qr=mysql_query("select m.name as menu, rd.quantity as quantity, rd.notes as notes, m.id as menuid, r.uniqueid as uniqueid, m.sub_category_id as subcat, m.cat_id as cat from reservation_detail as rd, menu as m, reservation as r where m.id=rd.menu_id and r.id=rd.reservation_id and rd.reservation_id='".$rr['id']."' and rd.lunchmeny=0") or die(mysql_error());
		$formsg.='<table width="100%">';
		while($rq=mysql_fetch_assoc($qr)){
			
			//for optional menus
			
			$tillval='';
			
			$opt_sql = "select a.name as name,a.price as price, dish_num from reservation_menu_option as a where reservation_unique_id = '".$rq['uniqueid']."' and a.menu_id=".$rq['menuid']." order by dish_num";
					
			$opt_query = mysql_query($opt_sql) or die(mysql_error());
			if(mysql_num_rows($opt_query)>0){
				//$tillval.='<div style="text-align:left; padding:10px 5px 10px; font-size:12px;">';
				$counter = 0;
				while($opt = mysql_fetch_assoc($opt_query)){
						$opt_tot += $opt['price'];
						if($counter<$opt['dish_num']){
							$counter = $counter+1;
							if($counter > 1){
								$tillval.='<br />';
							}
							$tillval.='Portion #'.$counter;
							
						}
						if($opt['price']==0){
							$opt_price = '0 kr';
						}else{
							$opt_price = number_format($opt['price'],0).' kr';
						}
						$tillval.='<div style="padding-top:5px;"><em>';
						$tillval.='<div><span>'.$opt['name'].'</span></div>';
						$tillval.='</em></div>';
					}
				//$tillval.='</div>';
			}
		
			//end
			
			$subcat = getTakeawayCategorySubcategory($rq['subcat'],'sub_category').' - ';
					
			if($rq['subcat']==0){
				$subcat = getTakeawayCategorySubcategory($rq['cat'],'category').' - ';
			}
			
			$formsg.='
					<tr>
						<td width="22%">Maträtt:</td>
						<td align="left">'.$subcat.strip_tags($rq['menu']).'</td>
					</tr>
					<tr>
						<td>Antal portioner:</td>
						<td align="left">'.$rq['quantity'].'</td>
					</tr>
					<tr>
						<td>Tillval:</td>
						<td align="left">'.$tillval.'</td>
					</tr>
					<tr>
						<td>Specialla önskemål:</td>
						<td align="left">'.strip_tags($rq['notes']).'</td>
					</tr>';
			
		}
		
		
		//for breakfast
		
		$qb=mysql_query("select m.name as menu, rd.quantity as quantity, rd.notes as notes, m.id as menuid, r.uniqueid as uniqueid from reservation_detail as rd, breakfast_menu as m, reservation as r where m.id=rd.menu_id and r.id=rd.reservation_id and rd.reservation_id='".$rr['id']."' and rd.lunchmeny=2") or die(mysql_error());
		$formsg.='<table width="100%">';
		while($rqb=mysql_fetch_assoc($qb)){
			
			//for optional menus
			
			$tillval='';
			
			$opt_sql = "select a.name as name,a.price as price, dish_num from reservation_menu_option as a where reservation_unique_id = '".$rq['uniqueid']."' and a.menu_id=".$rqb['menuid']." order by dish_num";
					
			$opt_query = mysql_query($opt_sql) or die(mysql_error());
			if(mysql_num_rows($opt_query)>0){
				//$tillval.='<div style="text-align:left; padding:10px 5px 10px; font-size:12px;">';
				$counter = 0;
				while($opt = mysql_fetch_assoc($opt_query)){
						$opt_tot += $opt['price'];
						if($counter<$opt['dish_num']){
							$counter = $counter+1;
							if($counter > 1){
								$tillval.='<br />';
							}
							$tillval.='Portion #'.$counter;
							
						}
						if($opt['price']==0){
							$opt_price = '0 kr';
						}else{
							$opt_price = number_format($opt['price'],0).' kr';
						}
						$tillval.='<div style="padding-top:5px;"><em>';
						$tillval.='<div><span>'.$opt['name'].'</span></div>';
						$tillval.='</em></div>';
					}
				//$tillval.='</div>';
			}
		
			//end
			
			$formsg.='
					<tr>
						<td width="22%">Maträtt:</td>
						<td align="left">'.strip_tags($rqb['menu']).'</td>
					</tr>
					<tr>
						<td>Antal portioner:</td>
						<td align="left">'.$rqb['quantity'].'</td>
					</tr>
					<tr>
						<td>Tillval:</td>
						<td align="left">'.$tillval.'</td>
					</tr>
					<tr>
						<td>Specialla önskemål:</td>
						<td align="left">'.strip_tags($rqb['notes']).'</td>
					</tr>';
			
		}
		
		
		//for lunchmeny
		
		$qs=mysql_query("select ml.name as menu, rd.quantity as quantity, rd.notes as notes, rd.menu_id as menuid, r.uniqueid as uniqueid, rd.dagenslunch as dagens from reservation_detail as rd, menu_lunch_items as ml, reservation as r where ml.id=rd.menu_id and r.id=rd.reservation_id and rd.reservation_id='".$rr['id']."' and rd.lunchmeny=1") or die(mysql_error());
		
		while($rqs=mysql_fetch_assoc($qs)){
			
			//for optional menus
			
			$tillvals='';
			$themenuname = strip_tags($rqs['menu']);
			if($rqs['dagens']==1){
				$themenuname = 'Dagens Lunch';
			}
			
			$formsg.='
					<tr>
						<td width="22%">Maträtt:</td>
						<td align="left">'.$themenuname.'</td>
					</tr>
					<tr>
						<td>Antal portioner:</td>
						<td align="left">'.$rqs['quantity'].'</td>
					</tr>
					<tr>
						<td>Tillval:</td>
						<td align="left">'.$tillvals.'</td>
					</tr>
					<tr>
						<td>Specialla önskemål:</td>
						<td align="left">'.strip_tags($rqs['notes']).'</td>
					</tr>';
			
		}
		
		
		if(getNameofSignee($rr['id'])!=''){
			$formsg.='<tr>
						<td width="22%">Din order togs emot av:</td>
						<td align="left">'.getNameofSignee($rr['id']).'</td>
					</tr>';
		}
		
		$formsg.='<tr>
						<td>Betalsätt:</td>
						<td align="left">'.paymentMode($rr['id']).'</td>
					</tr>';
		
		$formsg.='</table><br>';
		
		$q=mysql_query("select fname,lname, email from account where id='".$rr['accountid']."'") or die(mysql_error());
		$r=mysql_fetch_assoc($q);
		
		
		$delivermsg='Ungefärlig leveranstidpunkt:';
		
		$qd=mysql_query("select deliver from reservation where id='".$rr['id']."'");
		$rd=mysql_fetch_assoc($qd);
		
		if($rd['deliver']==0){
			$delivermsg='Klar för avhämtning:';
		}
			
		$to = $r['email'];
			
		$name=$r['fname'].' '.$r['lname'];
					
		$subject = 'Bekräftelse - Take away';
			
		// message
		$message = "
			<html>
				<body>
					<div style='font-size:13px;'>
						Hej ".trim($r['fname'])."! <br><br>
	
						Tack för din beställning. Nedan följer en sammanställning av din order. <br><br>
						
						<div>".$formsg."</div>
						<div style='clear:both'></div>
						".$delivermsg." ".date('d F Y',strtotime($thedate)).', klockan '.date('H:i',strtotime($thetime))." <br><br>
						 
						Välkommen till John Chris Coffee!<br><br>
						 
						Drottninggatan 29 <br>
						08-10 70 67 <br>
					</div>
				</body>
			</html>
		";
		
		//updating the asap time
		$asap_datetime = $thedate.' '.$thetime;
		mysql_query("update reservation set asap_datetime='".$asap_datetime."' where id='".$id."'") or die(mysql_error());
		
	}
			
		$mail = new PHPMailer();
		$mail->CharSet = 'UTF-8';
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $garcon_settings['smtp_host'];
		$mail->Port = $garcon_settings['smtp_port'];
		$mail->SMTPSecure = $garcon_settings['smtp_security'];
		$mail->SMTPAuth = true;
		$mail->Username = $garcon_settings['smtp_user'];
		$mail->Password = $garcon_settings['smtp_pass'];
		$mail->setFrom($garcon_settings['smtp_user'], $garcon_settings['smtp_from']);
		$mail->Subject = $subject;
		$mail->msgHTML($message);
	
		$mail->Subject = $subject;
		
		$mail->msgHTML($message);
		
		$mail->AddAddress($to, $name);
		$mail->send();
		
	
	echo $_SESSION['login']['name'];
	
?>