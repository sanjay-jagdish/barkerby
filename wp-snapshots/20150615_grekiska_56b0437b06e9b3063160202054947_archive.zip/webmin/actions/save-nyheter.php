<?php session_start();
	include '../config/config.php';
	
	$title = strip_tags($_POST['title']);
	$bodytext = mysql_real_escape_string($_POST['bodytext']);
	
	mysql_query("update nyheter set title = '$title', bodytext = '$bodytext' where id = 1") or die('didodo');
	
	echo '1';
?>