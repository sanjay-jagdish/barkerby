<?php session_start();
	include '../config/config.php';
	require 'PHPMailer/PHPMailerAutoload.php';	
	
	$id=strip_tags($_POST['id']);
	$status=mysql_real_escape_string(strip_tags($_POST['status']));
	
	$default=0;
	$thereason=mysql_real_escape_string(strip_tags($_POST['reason']));
	
	if($status!=14){
	
		if(isset($thereason)){
			mysql_query("update reservation set approve=".$status.", reason='".$thereason."', approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id);
		}
		else{
			$default=1;
		}
		
		$default2=0;
		$customtime=mysql_real_escape_string(strip_tags($_POST['customtime']));
		
		if(isset($customtime)){
			
			$ctime=explode(" ",$customtime);
			
			mysql_query("update reservation set approve=".$status.", lead_time='".$ctime[0]."', approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id);
		}
		else{
			$default2=1;
		}
		
		if($default==1 & $default2==1){
			mysql_query("update reservation set approve=".$status.", reason='', lead_time=0, approve_by=".$_SESSION['login']['id'].", acknowledged=1 where id=".$id);
		}
	
		mysql_query("insert into log(account_id,description,date_time,ip_address) values(".$_SESSION['login']['id'].",'Set order-status of an order as ".orderStatus($status).".',now(),'".get_client_ip()."')");
		
		//get status minutes
		
		$qy=mysql_query("select minutes from status where id='".$status."'");
		$ry=mysql_fetch_assoc($qy);
		
		$minutes = $ry['minutes'];
		
		if($minutes==0){
			
			$qqy=mysql_query("select lead_time from reservation where id='".$id."'");
			$rry=mysql_fetch_assoc($qqy);
			
			$minutes = $rry['lead_time'];
			
		}

	
		//for mail
		
		//SELECT ADDTIME(time, SEC_TO_TIME($minutes*60)), time FROM `reservation` order by id asc
	
			//check if the order is asap
			
			$qry=mysql_query("select asap from reservation where deleted=0 and id='".$id."'");
			$rqy=mysql_fetch_assoc($qry);
	
			if($rqy['asap']==1){
				//if asap orders
				$qq=mysql_query("select id, DATE_FORMAT(curdate(),'%b %d, %Y') as thedate, DATE_FORMAT(ADDTIME(now(), SEC_TO_TIME(".$minutes."*60)),'%H:%i') as time, account_id as accountid from reservation where id='".$id."'"); 
			}
			else{
				$qq=mysql_query("select id, DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'),'%b %d, %Y') as thedate, DATE_FORMAT(time,'%k:%i') as time, account_id as accountid from reservation where id='".$id."'"); 
			}
			
			$rr=mysql_fetch_assoc($qq);
			
			//added for mailing
			
			$formsg='';
			$qr=mysql_query("select m.name as menu, rd.quantity as quantity, rd.notes as notes from reservation_detail as rd, menu as m where m.id=rd.menu_id and rd.reservation_id='".$rr['id']."'");
			while($rq=mysql_fetch_assoc($qr)){
				
				$formsg.='Maträtt: '.$rq['menu'].' <br> 
						  Antal portioner: '.$rq['quantity'].' <br> 
						  Övriga önskemål: '.$rq['notes'].' <br><br>';
				
			}
			
			
			$q=mysql_query("select fname,lname, email from account where id='".$rr['accountid']."'");
			$r=mysql_fetch_assoc($q);
			
				
			$to = $r['email'];
				
			$name=$r['fname'].' '.$r['lname'];
						
			$subject = 'Bekräftelse - Take away';
				
			// message
			$message = "
				<html>
					<body>
						Hej ".$r['fname']."! <br><br>
 
						Tack för din beställning. Nedan följer en sammanställning av din order. <br><br>
						
						".$formsg."
						
						Klar för avhämtning: ".$rr['thedate'].' '.$rr['time']." <br><br>
						 
						Välkommen till Limone Ristorante Italiano! <br><br>
						 
						Stora gatan 4 <br>
						021-417560 <br>
					</body>
				</html>
			";
			
			//updating the asap time
			$asap_datetime = $rr['thedate'].' '.$rr['time'];
			mysql_query("update reservation set asap_datetime='".$asap_datetime."' where id='".$id."'");
			
	}
	else{
		
			mysql_query("update reservation set deleted=1 where id=".$id);
			
			$q=mysql_query("select fname,lname, email from account where id=(select account_id from reservation where id='".$id."')");
			$r=mysql_fetch_assoc($q);
			
			$to = $r['email'];
				
			$name=$r['fname'].' '.$r['lname'];
			
			$subject = 'Status - Take away';
			
			// message
			$message = "
				<html>
					<body>
						Hej ".$r['fname']."! <br><br>
 
						Your order has been cancelled. <br><br>
						 
						Stora gatan 4 <br>
						021-417560 <br>
					</body>
				</html>
			";
		
	}
				
				
			$mail = new PHPMailer();
			$mail->isSMTP();
			$mail->SMTPDebug = 0;
			$mail->Host = $garcon_settings['smtp_host'];
			$mail->Port = $garcon_settings['smtp_port'];
			$mail->SMTPSecure = $garcon_settings['smtp_security'];
			$mail->SMTPAuth = true;
			$mail->Username = $garcon_settings['smtp_user'];
			$mail->Password = $garcon_settings['smtp_pass'];
			$mail->setFrom($garcon_settings['smtp_user'], $garcon_settings['smtp_from']);
			$mail->Subject = $subject;
			$mail->msgHTML($message);
		
			$mail->Subject = $subject;
			
			$mail->msgHTML($message);
			
			$mail->AddAddress($to, $name);
			$mail->send();
		
	
	echo $_SESSION['login']['name'];
	
	
?>