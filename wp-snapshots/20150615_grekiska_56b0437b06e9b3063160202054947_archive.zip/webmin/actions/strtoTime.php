<?php
	echo strtotime($_POST['str']);
?>