<?php session_start();
	include '../config/config.php';
	
	function processedBy($id){
		if($id!=''){
			
			$q=mysql_query("select concat(fname,' ',mname,' ',lname) from account where id=".$id);
			$r=mysql_fetch_array($q);
			
			return $r[0];
			
		}
		else{
			return '';
		}
	}
	
	
	$id=strip_tags($_POST['id']);

	$qry = mysql_query(" UPDATE reservation SET `viewed` = '1' WHERE  `id` = ".$id);
	
	$q=mysql_query("select concat(a.fname,' ',a.mname,' ',a.lname) as name, rt.description as descrip, r.approve as approve, r.date as date, r.time as time, r.number_people as numpeople, r.number_table as numtable, r.approve_by as appby, r.note as note, r.date_time as datetime, r.reservation_type_id as resid, r.uniqueid as uniqueid, r.reason as reason, a.email as email, a.mobile_number as mob, a.phone_number as phone, a.street_name as street, r.lead_time as lead, r.acknowledged as ack,a.city as city, a.state as state, a.zip as zip, a.country as country, r.asap as asap, r.payment_mode as payment from reservation as r, reservation_type as rt, account as a where a.id=r.account_id and rt.id=r.reservation_type_id and r.id=".$id) or die(mysql_error());
	
	
	$r=mysql_fetch_assoc($q);
	
	$customer=$r['name'];
	$type=$r['descrip'];
	$status=$r['approve'];
	$date=$r['date'];
	$time=$r['time'];
	$num_people=$r['numpeople'];
	$num_table=numberTable($id);
	$accountID=$r['appby'];
	$note=$r['note'];
	$date_time=$r['datetime'];
	$typeID=$r['resid'];
	$reason=$r['reason'];
	$email=$r['email'];
	$mobile=$r['mob'];
	$phone=$r['phone'];
	$customtime=$r['lead'];
	$acknowledged=$r['ack'];
	$street=$r['street'];
	$city=$r['city'];
	$state=$r['state'];
	$zip=$r['zip'];
	$country=$r['country'];
	$asap=$r['asap'];
	$payment=$r['payment'];
	$uniqueid = $r['uniqueid'];
	
	
	$number='';
	if($mobile!='' & $phone!=''){
		$number.=$mobile.' / '.$phone;
	}
	else{
		if($mobile!=''){
			$number=$mobile;
		}
		else if($phone!=''){
			$number=$phone;
		}
	}
	
	$address='';
						
	if($street!=''){
		$address.=$street.',';
	}
	if($city!=''){
		$address.=$city;
	}
	if($state!=''){
		$address.=','.$state;
	}
	if($zip!=''){
		$address.=','.$zip;
	}
	if($country!=''){
		$address.=','.$country;
	}
	
?>

<script type="text/javascript">
jQuery(function(){

	
	
	jQuery('.cancelbox input[type=button]').click(function(){
		var val=jQuery('.cancelbox textarea').val();
		
		jQuery('.cancelbox .displaymsg').fadeOut('slow');
		
		if(val!=''){
			
			var stat=jQuery('.order-status').val();
			
			jQuery.ajax({
				 url: "actions/order-status.php",
				 type: 'POST',
				 data: 'status='+encodeURIComponent(stat)+'&id=<?php echo $id; ?>'+'&reason='+encodeURIComponent(val),
				 success: function(value){
					 jQuery('.processedby').html(value);
				 }
			});
			
			jQuery('.order-status').val(stat);
			jQuery('.reason').html(val);
			jQuery('.fade2, .cancelbox').fadeOut('slow');
			
			setTimeout("window.location.reload();",1000);
			
		}
		else{
			jQuery('.cancelbox .displaymsg').fadeIn('slow').addClass('errormsg').html('Field should not be empty.');
		}
		
	});
	
	jQuery('.order-detail-btn').click(function(){
		
		var acknowledge=jQuery('.acknowledge:checked').length;
		
		var ack=jQuery('.acknowledge').length;
		
		jQuery('.displaymsg-new').fadeOut('slow')
		
		if(ack==1){
			if(acknowledge==1){
				jQuery('.proceedbox .displaymsg').hide();
				jQuery('.fade2, .proceed-order-box').fadeIn('slow');
			}
			else{
				jQuery('.displaymsg-new').fadeIn('slow').addClass('errormsg').html('Please acknowledge first this reservation by clicking the checbox.');
			}
		}
		else{
			jQuery('.proceedbox .displaymsg').hide();
			jQuery('.fade2, .proceed-order-box').fadeIn('slow');
		}
		
	});
	
	jQuery('.proceedbox input[type=button]').click(function(){
		
		var val=jQuery('.order-status').val();
		
		if(val==6){
			jQuery('.cancelbox .displaymsg').hide();
			jQuery('.proceedbox').fadeOut();
			jQuery('.fade2, .cancelbox').fadeIn();
		}
		else{
			
			if(val==12){
				
				jQuery('.proceedbox .displaymsg').fadeOut('slow');
				
				if(jQuery('.thecustom').html() != ''){
					
					jQuery.ajax({
						 url: "actions/order-status.php",
						 type: 'POST',
						 data: 'status='+encodeURIComponent(val)+'&id=<?php echo $id; ?>'+'&customtime='+encodeURIComponent(jQuery('.thecustom').html()),
						 success: function(value){
							 jQuery('.processedby').html(value);
							 jQuery('.fade, .orderbox, .fade2, .proceed-order-box').fadeOut('slow');
							 
							 setTimeout("window.location.reload();",1000);
						 }
					});
					jQuery('.reason').html('');
					
				}
				else{
					jQuery('.proceedbox .displaymsg').fadeIn('slow').addClass('errormsg').html('Please set your Custom Time.');
				}
				
			}
			else{
				
				var signatory = 0;
				
				if($(this).attr('data-rel')==1){
					signatory = $('#signatory').attr('data-rel');
				}
								
				jQuery.ajax({
					 url: "actions/order-status.php",
					 type: 'POST',
					 data: 'status='+encodeURIComponent(val)+'&id=<?php echo $id; ?>&signed='+signatory,
					 success: function(value){
						 jQuery('.processedby').html(value);
						 jQuery('.fade, .orderbox, .fade2, .proceed-order-box').fadeOut('slow');
						 
						 setTimeout("window.location.reload();",1000);
					 }
				});
				jQuery('.reason').html('');
			
			}
		}
	
	});
	
	jQuery('.order-status').change(function(){
		if(this.value==12){
			jQuery('.custombox .displaymsg').hide();
			jQuery('.fade2, .custombox').fadeIn();
		}
		else{
			jQuery('.thecustom').html('');
		}
	});
	
	jQuery('.custombox input[type=button]').click(function(){
		var ctime=jQuery('.customtime').val();
		
		jQuery('.custombox .displaymsg').fadeOut('slow');
		
		if(ctime!=''){
			if(ctime > 0){
				
				jQuery('.thecustom').html(jQuery('.customtime').val()+' min');
				jQuery('.fade2, .custombox').fadeOut();
				
			}
			else{
				jQuery('.custombox .displaymsg').fadeIn('slow').addClass('errormsg').html('Minutes should be greater than 0.');
			}
		}
		else{
			jQuery('.custombox .displaymsg').fadeIn('slow').addClass('errormsg').html('Field is required.');
		}
	});
	
});	
</script>
<style>
	.invoice-info{
		
	}
	.invoice-info span{
		width:100px;
		display:inline-block;
	}
</style>

<table width="100%">
	<tr align="left">
    	<td width="180px">Bokning mottagen :</td>
        <td><?php echo date("d F Y G:i",strtotime($date_time)); ?></td>
    </tr>
	<tr align="left">
    	<td>Namn :</td>
        <td><?php echo $customer; ?></td>
    </tr>
    <tr align="left">
    	<td>E-post :</td>
        <td><?php echo $email; ?></td>
    </tr>
    <tr align="left">
    	<td>Mobilnummer :</td>
        <td><?php echo $number; ?></td>
    </tr>
    <tr align="left">
    	<td>Adress :</td>
        <td><?php echo $address; ?></td>
    </tr>
    <tr align="left">
    	<td>Typ av bokning :</td>
        <td><?php echo $type; ?></td>
    </tr>
    <?php if($typeID==1){ ?>
    <tr align="left">
    	<td>Datum :</td>
        <td><?php echo date("d F Y",strtotime($date)); ?></td>
    </tr>
    <tr align="left">
    	<td>Tid :</td>
        <td><?php echo $time; ?></td>
    </tr>
    <tr align="left">
    	<td>Antal personer :</td>
        <td><?php echo $num_people; ?></td>
    </tr>
    <tr align="left">
    	<td>Antal bord :</td>
        <td><?php echo $num_table; ?></td>
    </tr>
    <?php }
		else if($typeID==2){
	?>
    <tr align="left">
    	<td>Hämtas, datum :</td>
        <td><?php 
				if($date!=''){
					echo date("d F Y",strtotime($date));
				}
				else{
					echo '-';
				}
			?>
        </td>
    </tr>
    <tr align="left">
    	<td>Hämtas, tid :</td>
        <td><?php 
			
			if($asap==0){
				if($time=='00:00:00'){
					echo '-';
				}
				else{
					echo date("G:i",strtotime($time)); 
				}
			}
			else{
				echo 'Snarast';
			}
			
			?>
         </td>
    </tr>	
    <?php	
		}
	?>
    <!--<tr align="left">
    	<td>Övrigt :</td>
        <td><?php //echo $note; ?></td>
    </tr>-->
    <tr align="left">
    	<td valign="top">Betalsätt :</td>
        <td>
			<?php 
				if($payment=='cash'){
					echo 'Kort/Kontant';
				}
				else if($payment=='invoice'){
					echo '<strong>Faktura</strong>';
					$inv_query = mysql_query("select * from invoice where reservation_unique_id = '$uniqueid'") or die(mysql_error());
					if($inv = mysql_fetch_assoc($inv_query)){
						echo '<div class="invoice-info">';
						echo '<div><span>Företag:</span>'.$inv['business'].'</div>';
						echo '<div><span>Orgnr:</span>'.$inv['org_number'].'</div>';
						echo '<div><span>Postadress:</span>'.$inv['address'].'</div>';
						echo '<div><span>Postnummer:</span>'.$inv['zip'].'</div>';
						echo '<div><span>Ort:</span>'.$inv['location'].'</div>';
						echo '</div>';
					}
				}
		   ?>
        </td>
    </tr>
    <tr align="left">
    	<td>Status :</td>
        <td>
        
        	<?php
			
			if($status==8){
			
				$condition='and (id=13 or id=14)';
            	if($asap==1){
					$condition='and (id<>13)';
				}
			?>
        
        	<select class="order-status" data-rel="<?php echo $status; ?>">
            	<?php
                	$q=mysql_query("select id,description from status where reservation_type_id=".$typeID." and deleted=0 $condition");
					while($r=mysql_fetch_array($q)){
				?>
               	 <option value="<?php echo $r[0];?>" <?php if($r[0]==$status) echo 'selected="selected"'; ?>>
				 	<?php 
					
						if($r[1] == 'Approve'){
							echo 'Godkänd beställning';
						}else if($r[1] == 'Cancel'){
							echo 'Ej godkänd beställning';
						}
						else{
							echo $r['description'];
						}
						//echo ucwords($r[1]); 
					
					?>
                 </option>
                <?php		
					}
				?>
            </select>
            
            <?php }
				else{
					
					$q=mysql_query("select description from status where deleted=0 and id='".$status."'");
					$r=mysql_fetch_assoc($q);
					
					// echo $r['description'];

					if($r['description'] == 'Approve'){
						echo 'Godkänd beställning';
					}else if($r['description'] == 'Cancel'){
						echo 'Ej godkänd beställning';
					}
					else
						echo $r['description'];
				}
			?>
            
			<span class="reason"><?php echo $reason;?></span>
            <span class="thecustom"><?php if($customtime!=0) echo $customtime.' min'; ?></span>
		
        </td>
    </tr>
    <?php if($typeID==1){ ?>
    <tr align="left">
    	<td>Bekräfta :</td>
        <td><input type="checkbox" class="acknowledge" <?php if($acknowledged==1) echo 'checked="checked"';?>></td>
    </tr>
    <?php } ?>
    <tr align="left">
    	<td>Bearbetad av :</td>
        <td class="processedby"><?php echo processedBy($accountID); ?></td>
    </tr>
    <?php if($status==8){?>
    <tr align="left">
    	<td class="2"><input type="button" class="btn order-detail-btn" value="Utför"></td>
    </tr>
    <?php } ?>
</table>

<div class="displaymsg displaymsg-new"></div>

<?php if($typeID==2){ ?>
<div class="menu-selected">
	<span class="title">Beställda rätter</span>
	<table width="100%">
    	<tr style="background: #ddd;">
        	<td style="padding: 8px 0;">Rätt</td>
            <td>Kategori	</td>
            <td>Bild</td>
            <td>Pris</td>
            <td>Antal</td>
            <td>Totalt</td>
            <td>Önskemål</td>
        </tr>
        <?php
        	$q=mysql_query("select m.name as menu, c.name as sub, m.image as img, m.price as price, rd.quantity as quantity, cu.shortname as currency, rd.notes as notes, c.id as cid, m.type as type, m.discount as discount from reservation_detail as rd, menu as m, sub_category as c, currency as cu where m.id=rd.menu_id and c.id=m.sub_category_id and cu.id=m.currency_id and rd.reservation_id=".$id) or die(mysql_error());
			$count=0;
			$total=0;
			$currency='';
			while($r=mysql_fetch_assoc($q)){
				$count++;
				
				$price=$r['price'];
				if(strlen($r['type'])>1){
					
					$discount=$r['discount']/100;
					$price=$price-($price*$discount);
				}
				
				
				$images='images/no-photo-available.jpg';
				if($r['img']!=''){
					$images='uploads/'.$r['img'];
				}
				
				$subtotal=$price*$r['quantity'];
				
		?>
        <tr style="background:<?php if($count%2==0) echo '#ddd'; else echo '#fff';?>" class="menuvalues">
        	<td width="200px"><?php echo $r['menu']; ?></td>
            <td><?php echo $r['sub'].' - '.getCategoryName($r['cid']); ?></td>
            <td><img src="<?php echo $images; ?>" width="60"></td>
            <td><?php echo $price.' '.$r['currency']; ?></td>
            <td><?php echo $r['quantity']; ?></td>
            <td><?php echo $subtotal.' '.$r['currency']; ?></td>
            <td><?php echo $r['notes']; ?></td>
        </tr>	
        <?php		
				$total+=$subtotal;
				$currency=$r['currency'];
			}
		?>
        <tr style="font-weight:bold;">
        	<td colspan="5" style="padding:5px; text-align:right;">Slutsumma :</td>
            <td><?php echo $total.' '.$currency; ?></td>
        </tr>
    </table>
</div>
<?php } ?>